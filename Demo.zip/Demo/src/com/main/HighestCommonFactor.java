package com.main;

public class HighestCommonFactor {

	public static void main(String[] args) {
		int arr[] = { 39, 65, 91, 117 };

		int result = highestCommonFactor(arr);
		
		System.out.println(result);

	}

	private static int highestCommonFactor(int[] arr) {

		int result = arr[0];

		for (int i = 1; i < arr.length; i++)
			result = gcd(arr[i], result);

		
		return result;
	}

	static int gcd(int a, int b) {
		if (a == 0)
			return b;
		return gcd(b % a, a);
	}
}
