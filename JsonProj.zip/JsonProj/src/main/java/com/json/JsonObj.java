package com.json;

import java.io.FileReader;
import java.io.FileWriter;
import java.util.List;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

public class JsonObj {
	public static void main(String[] args) throws Exception {
		Object obj = new JSONParser().parse(new FileReader("src\\main\\resources\\addresses.json"));
		ObjectMapper objectMapper = new ObjectMapper();
		List<Address> addressList = objectMapper.readValue(objectMapper.writeValueAsString(obj),
				new TypeReference<List<Address>>() {
				});
		printversionofanaddress(addressList);
		writejsondatatofile(addressList);
		addressofcertaintype(addressList);
		addressvalidate(addressList);
	}

	private static void addressvalidate(List<Address> addressList) {
		for (Address address : addressList) {
			boolean numeric = true;

			numeric = address.getPostalCode().matches("-?\\d+(\\.\\d+)?");

			if (numeric && address.getAddressLineDetail() != null
					&& address.getAddressLineDetail().getLine2() != null) {
				System.out.println(address.getPostalCode() + " - " + address.getCountry().getName() + " - "
						+ address.getAddressLineDetail().getLine2());
			}
			if (address.getCountry().getCode().equalsIgnoreCase("ZA")) {
				System.out.println("if country code ZA = " + address.getCountry().getName());
			}

		}
	}

	private static void addressofcertaintype(List<Address> addressList) {
		for (Address address : addressList) {
			if (address.getType().getName().equalsIgnoreCase("Physical Address")) {
				System.out.println(address.getType().getName());
			}
			if (address.getType().getName().equalsIgnoreCase("Postal Address")) {
				System.out.println(address.getType().getName());
			}
			if (address.getType().getName().equalsIgnoreCase("Business Address")) {
				System.out.println(address.getType().getName());
			}
		}
	}

	@SuppressWarnings("unchecked")
	private static void writejsondatatofile(List<Address> addressList) {
		JSONObject jsonObject = new JSONObject();
		for (Address address : addressList) {

			if (address.getAddressLineDetail() != null && address.getAddressLineDetail().getLine2() != null) {
				jsonObject.put("line2", address.getAddressLineDetail().getLine2());
				jsonObject.put("line1", address.getAddressLineDetail().getLine1());
			}

		}
		try {
			FileWriter file = new FileWriter("src\\main\\resources\\address.json");
			file.write(jsonObject.toJSONString());
			file.close();
		} catch (Exception e) {
		}
	}

	private static void printversionofanaddress(List<Address> addressList) {
		for (int i = 0; i < addressList.size(); i++) {
			if (addressList.get(i).getAddressLineDetail() != null) {
				System.out.print(addressList.get(i).getAddressLineDetail().getLine1() + " - ");
			}
			System.out.print(addressList.get(i).getCityOrTown() + " - ");
			System.out.print(addressList.get(i).getPostalCode() + " - ");
			System.out.print(addressList.get(i).getCountry().getName() + " - ");

		}
	}

}
